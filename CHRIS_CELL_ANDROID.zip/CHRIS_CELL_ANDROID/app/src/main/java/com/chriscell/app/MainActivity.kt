package com.chriscell.app

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val bg = Color.rgb(7, 12, 18)
    private val surface = Color.rgb(16, 23, 32)
    private val surface2 = Color.rgb(22, 31, 42)
    private val line = Color.rgb(42, 54, 68)
    private val white = Color.WHITE
    private val muted = Color.rgb(155, 168, 184)
    private val blue = Color.rgb(56, 189, 248)
    private val green = Color.rgb(52, 211, 153)
    private val orange = Color.rgb(251, 146, 60)
    private val red = Color.rgb(248, 113, 113)

    private val prefs by lazy { getSharedPreferences("estoque", MODE_PRIVATE) }
    private lateinit var content: LinearLayout
    private var currentCategory = "Todos"
    private var currentStatus = "Todos"
    private var searchText = ""
    private var editingIndex = -1
    private var selectedPhoto = ""

    private val pickPhoto = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        selectedPhoto = uri.toString()
        renderForm()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showHome()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(bg)
        setPadding(dp(18), dp(14), dp(18), dp(18))
    }

    private fun text(value: String, size: Float, color: Int = white, bold: Boolean = false): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun rounded(color: Int, radius: Int = 16, stroke: Int? = null): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            stroke?.let { setStroke(dp(1), it) }
        }

    private fun button(label: String, action: () -> Unit, primary: Boolean = false): Button = Button(this).apply {
        text = label
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        isAllCaps = false
        setTextColor(if (primary) Color.rgb(3, 13, 20) else white)
        background = rounded(if (primary) blue else surface2, 14, if (primary) null else line)
        setPadding(dp(10), 0, dp(10), 0)
        setOnClickListener { action() }
        minHeight = dp(48)
    }

    private fun header(root: LinearLayout, subtitle: String = "ESTOQUE • ASSISTÊNCIA • VENDAS") {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val logo = text("CHRIS CELL", 25f, white, true)
        val sub = text(subtitle, 10f, muted, true)
        titles.addView(logo); titles.addView(sub)
        row.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        val badge = text("JP", 12f, bg, true).apply { gravity = Gravity.CENTER; background = rounded(blue, 50) }
        row.addView(badge, LinearLayout.LayoutParams(dp(40), dp(40)))
        root.addView(row, LinearLayout.LayoutParams(-1, dp(54)))
    }

    private fun searchBox(root: LinearLayout) {
        val search = EditText(this).apply {
            hint = "🔎  Buscar aparelho..."
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 14f
            singleLine = true
            setPadding(dp(16), 0, dp(16), 0)
            background = rounded(surface, 15, line)
            setText(searchText)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) { searchText = s?.toString()?.trim()?.lowercase(Locale.getDefault()) ?: ""; renderList() }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(12) })
    }

    private fun chipRow(root: LinearLayout, values: List<String>, selected: String, onPick: (String) -> Unit) {
        val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        values.forEach { value ->
            val b = button(value, { onPick(value) }, value == selected)
            row.addView(b, LinearLayout.LayoutParams(dp(if (value.length > 10) 125 else 95), dp(42)).apply { rightMargin = dp(8) })
        }
        scroll.addView(row)
        root.addView(scroll, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(8) })
    }

    private fun stats(root: LinearLayout) {
        val a = data()
        val total = a.length()
        val available = (0 until a.length()).count { a.getJSONObject(it).optString("status") == "Disponível" }
        val sold = (0 until a.length()).count { a.getJSONObject(it).optString("status") == "Vendido" }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        statCard(row, total.toString(), "TOTAL", blue)
        statCard(row, available.toString(), "DISPONÍVEIS", green)
        statCard(row, sold.toString(), "VENDIDOS", orange)
        root.addView(row, LinearLayout.LayoutParams(-1, dp(82)).apply { bottomMargin = dp(12) })
    }

    private fun statCard(row: LinearLayout, value: String, label: String, color: Int) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), 0, dp(8), 0); background = rounded(surface, 15, line) }
        box.addView(text(value, 21f, color, true))
        box.addView(text(label, 9f, muted, true))
        row.addView(box, LinearLayout.LayoutParams(0, -1, 1f).apply { rightMargin = dp(7) })
    }

    private fun showHome() {
        editingIndex = -1
        val root = base()
        header(root)
        stats(root)
        searchBox(root)
        chipRow(root, listOf("Todos", "Android", "iPhone", "Quebra-Galho"), currentCategory) { currentCategory = it; showHome() }
        chipRow(root, listOf("Todos", "Disponível", "Reservado", "Vendido"), currentStatus) { currentStatus = it; showHome() }

        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(content) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val add = button("＋  Cadastrar aparelho", { showForm(-1) }, true)
        root.addView(add, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(12) })
        setContentView(root)
        renderList()
    }

    private fun renderList() {
        if (!::content.isInitialized) return
        content.removeAllViews()
        val a = data()
        val items = mutableListOf<Pair<Int, JSONObject>>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val cat = o.optString("categoria", "Android")
            val status = o.optString("status", "Disponível")
            val hay = (o.optString("modelo") + " " + o.optString("especificacoes") + " " + cat).lowercase(Locale.getDefault())
            if ((currentCategory == "Todos" || cat == currentCategory) && (currentStatus == "Todos" || status == currentStatus) && (searchText.isEmpty() || hay.contains(searchText))) items.add(i to o)
        }
        if (items.isEmpty()) {
            val empty = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(20), dp(55), dp(20), dp(55)); background = rounded(surface, 18, line) }
            empty.addView(text("📱", 42f, blue, true).apply { gravity = Gravity.CENTER })
            empty.addView(text(if (a.length == 0) "Seu estoque está vazio" else "Nenhum aparelho encontrado", 18f, white, true).apply { gravity = Gravity.CENTER })
            empty.addView(text(if (a.length == 0) "Cadastre seu primeiro aparelho para começar." else "Tente mudar os filtros ou a busca.", 13f, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) })
            content.addView(empty)
            return
        }
        items.forEach { (index, o) -> content.addView(deviceCard(index, o), LinearLayout.LayoutParams(-1, dp(145)).apply { bottomMargin = dp(10) }) }
    }

    private fun deviceCard(index: Int, o: JSONObject): View {
        val card = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(10), dp(10), dp(10), dp(10)); background = rounded(surface, 18, line) }
        val photo = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            val uri = o.optString("foto")
            if (uri.isNotBlank()) try { setImageURI(Uri.parse(uri)) } catch (_: Exception) {}
            if (drawable == null) { setImageResource(android.R.drawable.ic_menu_gallery); setColorFilter(blue) }
            background = rounded(surface2, 14)
        }
        card.addView(photo, LinearLayout.LayoutParams(dp(105), -1).apply { rightMargin = dp(12) })
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val status = o.optString("status", "Disponível")
        val statusView = text(status, 10f, statusColor(status), true).apply { gravity = Gravity.CENTER; setPadding(dp(8), 0, dp(8), 0); background = rounded(statusColor(status).let { Color.argb(35, Color.red(it), Color.green(it), Color.blue(it) ) }, 20) }
        top.addView(statusView, LinearLayout.LayoutParams(-2, dp(27)))
        top.addView(Space(this), LinearLayout.LayoutParams(0, 1, 1f))
        top.addView(button("✎", { showForm(index) }, false).apply { minHeight = dp(38); minWidth = dp(42) }, LinearLayout.LayoutParams(dp(45), dp(42)))
        body.addView(top)
        body.addView(text(o.optString("modelo", "Aparelho"), 17f, white, true), LinearLayout.LayoutParams(-1, dp(31)))
        body.addView(text(o.optString("categoria") + " • " + o.optString("especificacoes"), 11f, muted), LinearLayout.LayoutParams(-1, dp(24)))
        body.addView(text(money(o.optString("preco")), 18f, blue, true), LinearLayout.LayoutParams(-1, dp(29)))
        body.addView(button("Excluir", { confirmDelete(index) }, false).apply { textSize = 10f; minHeight = dp(30); visibility = View.GONE })
        card.addView(body, LinearLayout.LayoutParams(0, -1, 1f))
        card.setOnClickListener { showForm(index) }
        return card
    }

    private fun statusColor(status: String): Int = when (status) { "Vendido" -> orange; "Reservado" -> blue; else -> green }

    private fun showForm(index: Int) {
        editingIndex = index
        val a = data()
        val old = if (index >= 0) a.getJSONObject(index) else JSONObject()
        selectedPhoto = old.optString("foto")
        renderForm(old)
    }

    private fun renderForm(old: JSONObject = if (editingIndex >= 0) data().getJSONObject(editingIndex) else JSONObject()) {
        val root = base()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(button("← Voltar", { showHome() }, false), LinearLayout.LayoutParams(dp(105), dp(44)))
        top.addView(text(if (editingIndex >= 0) "Editar aparelho" else "Novo aparelho", 22f, white, true).apply { setPadding(dp(12), 0, 0, 0) }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(top, LinearLayout.LayoutParams(-1, dp(58)).apply { bottomMargin = dp(8) })

        val photoBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(10), dp(10), dp(10), dp(10)); background = rounded(surface, 18, line) }
        val image = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; background = rounded(surface2, 14) }
        if (selectedPhoto.isNotBlank()) try { image.setImageURI(Uri.parse(selectedPhoto)) } catch (_: Exception) {}
        if (image.drawable == null) { image.setImageResource(android.R.drawable.ic_menu_camera); image.setColorFilter(blue) }
        photoBox.addView(image, LinearLayout.LayoutParams(dp(120), dp(120)))
        photoBox.addView(button(if (selectedPhoto.isBlank()) "Adicionar foto" else "Trocar foto", { pickPhoto.launch(arrayOf("image/*")) }, true), LinearLayout.LayoutParams(dp(170), dp(48)).apply { topMargin = dp(10) })
        root.addView(photoBox, LinearLayout.LayoutParams(-1, dp(205)).apply { bottomMargin = dp(12) })

        val cat = field("Categoria", old.optString("categoria", "Android"))
        val model = field("Modelo", old.optString("modelo"), "Ex.: iPhone 13 128 GB")
        val spec = field("Especificações", old.optString("especificacoes"), "Ex.: 128 GB • 6 GB RAM")
        val price = field("Preço", old.optString("preco"), "Ex.: 1299,90").apply { inputType = 8194 }
        val obs = field("Observações", old.optString("observacoes"), "Bateria, estado, acessórios, garantia...")
        val status = Spinner(this).apply { background = rounded(surface, 14, line); setPadding(dp(12), 0, dp(12), 0) }

        addLabel(root, "Categoria")
        cat.inputType = 1
        root.addView(cat, lpField())
        addLabel(root, "Modelo")
        root.addView(model, lpField())
        addLabel(root, "Especificações")
        root.addView(spec, lpField())
        addLabel(root, "Preço")
        root.addView(price, lpField())
        addLabel(root, "Status")
        val statuses = arrayOf("Disponível", "Reservado", "Vendido")
        status.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, statuses)
        status.setSelection(statuses.indexOf(old.optString("status", "Disponível")).coerceAtLeast(0))
        root.addView(status, lpField())
        addLabel(root, "Observações")
        obs.minLines = 3
        root.addView(obs, lpField())

        root.addView(button(if (editingIndex >= 0) "Salvar alterações" else "Cadastrar aparelho", {
            if (model.text.toString().trim().isEmpty()) { model.error = "Digite o modelo"; return@button }
            val o = JSONObject().apply {
                put("categoria", cat.text.toString().trim().ifBlank { "Android" })
                put("modelo", model.text.toString().trim())
                put("especificacoes", spec.text.toString().trim())
                put("preco", price.text.toString().trim().replace(',', '.'))
                put("status", status.selectedItem.toString())
                put("observacoes", obs.text.toString().trim())
                put("foto", selectedPhoto)
            }
            val arr = data()
            if (editingIndex >= 0) arr.put(editingIndex, o) else arr.put(0, o)
            save(arr)
            currentCategory = "Todos"; currentStatus = "Todos"; searchText = ""; showHome()
        }, true), LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(10) })

        if (editingIndex >= 0) root.addView(button("Excluir aparelho", { confirmDelete(editingIndex) }, false), LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(8) })
        setContentView(root)
    }

    private fun addLabel(root: LinearLayout, value: String) { root.addView(text(value, 11f, muted, true), LinearLayout.LayoutParams(-1, dp(24))) }

    private fun field(label: String, value: String, hint: String = ""): EditText = EditText(this).apply {
        setText(value); this.hint = hint; setHintTextColor(Color.rgb(105, 120, 137)); setTextColor(white); textSize = 14f; singleLine = label != "Observações"; setPadding(dp(14), 0, dp(14), 0); background = rounded(surface, 14, line)
    }

    private fun lpField() = LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(9) }

    private fun confirmDelete(index: Int) {
        AlertDialog.Builder(this).setTitle("Excluir aparelho?").setMessage("Esse item será removido do estoque.")
            .setNegativeButton("Cancelar", null).setPositiveButton("Excluir") { _, _ -> val a = data(); if (index in 0 until a.length()) { a.remove(index); save(a); showHome() } }.show()
    }

    private fun data(): JSONArray = try { JSONArray(prefs.getString("items", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
    private fun save(a: JSONArray) { prefs.edit().putString("items", a.toString()).apply() }

    private fun money(value: String): String = try {
        val n = value.replace("R$", "").replace(".", "").replace(",", ".").trim().toDouble()
        NumberFormat.getCurrencyInstance(Locale("pt", "BR")).format(n)
    } catch (_: Exception) { "R$ 0,00" }
}
