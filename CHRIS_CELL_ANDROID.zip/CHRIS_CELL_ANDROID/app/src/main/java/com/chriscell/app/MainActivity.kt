package com.chriscell.app

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.content.Context
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private val prefs by lazy { getSharedPreferences("estoque", Context.MODE_PRIVATE) }
    private val blue = Color.rgb(56,189,248)
    override fun onCreate(b: Bundle?) { super.onCreate(b); showHome() }
    private fun base(): LinearLayout { val l=LinearLayout(this); l.orientation=LinearLayout.VERTICAL; l.setPadding(24,20,24,20); l.setBackgroundColor(Color.rgb(11,13,16)); return l }
    private fun tv(t:String,size:Float=16f):TextView { return TextView(this).apply{ text=t; textSize=size; setTextColor(Color.WHITE); setPadding(0,8,0,8) } }
    private fun btn(t:String, action:()->Unit):Button { return Button(this).apply{ text=t; setOnClickListener{action()}; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(30,38,48)) } }
    private fun showHome(){ val root=base(); root.addView(tv("CHRIS CELL",28f)); root.addView(tv("Estoque de aparelhos",13f)); root.addView(btn("＋  CADASTRAR APARELHO"){showForm(-1)})
        list=LinearLayout(this); list.orientation=LinearLayout.VERTICAL; val sv=ScrollView(this); sv.addView(list); root.addView(sv,LinearLayout.LayoutParams(-1,0,1f)); setContentView(root); render() }
    private fun data():JSONArray=JSONArray(prefs.getString("items","[]"))
    private fun save(a:JSONArray){prefs.edit().putString("items",a.toString()).apply()}
    private fun render(){list.removeAllViews(); val a=data(); if(a.length()==0){list.addView(tv("Nenhum aparelho cadastrado ainda."));return}; for(i in 0 until a.length()){val o=a.getJSONObject(i); val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;box.setPadding(0,16,0,16);box.addView(tv(o.optString("modelo"),19f));box.addView(tv("${o.optString("categoria")} • ${o.optString("especificacoes")}",13f));box.addView(tv("R$ ${o.optString("preco")} • ${o.optString("status")}",16f));val row=LinearLayout(this);row.addView(btn("Editar"){showForm(i)},LinearLayout.LayoutParams(0,-2,1f));row.addView(btn("Excluir"){a.remove(i);save(a);render()},LinearLayout.LayoutParams(0,-2,1f));box.addView(row);list.addView(box)} }
    private fun showForm(index:Int){val a=data(); val old=if(index>=0)a.getJSONObject(index) else JSONObject(); val root=base();root.addView(tv(if(index>=0)"Editar aparelho" else "Cadastrar aparelho",24f));
        val cat=EditText(this);cat.hint="Categoria: Android / Quebra-Galho / iPhone";cat.setText(old.optString("categoria"));root.addView(cat)
        val model=EditText(this);model.hint="Modelo";model.setText(old.optString("modelo"));root.addView(model)
        val spec=EditText(this);spec.hint="Especificações (ex.: 128 GB • 6 GB RAM)";spec.setText(old.optString("especificacoes"));root.addView(spec)
        val price=EditText(this);price.hint="Preço";price.inputType=2 or 8192;price.setText(old.optString("preco"));root.addView(price)
        val status=EditText(this);status.hint="Status: Disponível / Reservado / Vendido";status.setText(old.optString("status","Disponível"));root.addView(status)
        val obs=EditText(this);obs.hint="Observações";obs.minLines=3;obs.setText(old.optString("observacoes"));root.addView(obs)
        root.addView(btn("SALVAR APARELHO"){if(model.text.toString().trim().isEmpty()){Toast.makeText(this,"Digite o modelo",Toast.LENGTH_SHORT).show();return@btn};val o=JSONObject();o.put("categoria",cat.text.toString());o.put("modelo",model.text.toString());o.put("especificacoes",spec.text.toString());o.put("preco",price.text.toString());o.put("status",status.text.toString().ifBlank{"Disponível"});o.put("observacoes",obs.text.toString());if(index>=0)a.put(index,o)else a.put(o);save(a);showHome()});root.addView(btn("VOLTAR"){showHome()});setContentView(root)}
}
