package com.chriscell.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("estoque", Context.MODE_PRIVATE) }
    private lateinit var content: LinearLayout
    private var selectedFilter = "Todos"
    private var searchText = ""
    private var clientMode = false
    private var pendingPhotoUris = mutableListOf<String>()
    private var editingIndex = -1
    private lateinit var photoRow: LinearLayout
    private val bg = Color.rgb(7, 10, 15)
    private val panel = Color.rgb(17, 23, 32)
    private val panel2 = Color.rgb(27, 35, 47)
    private val white = Color.WHITE
    private val muted = Color.rgb(157, 169, 186)
    private val cyan = Color.rgb(45, 211, 255)
    private val green = Color.rgb(61, 220, 151)
    private val orange = Color.rgb(251, 191, 36)
    private val red = Color.rgb(248, 113, 113)

    override fun onCreate(b: Bundle?) { super.onCreate(b); showHome() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun data() = JSONArray(prefs.getString("items", "[]"))
    private fun save(a: JSONArray) = prefs.edit().putString("items", a.toString()).apply()
    private fun money(s: String): String = try { NumberFormat.getCurrencyInstance(Locale("pt", "BR")).format(s.replace(",", ".").toDouble()) } catch (_: Exception) { if (s.isBlank()) "R$ 0,00" else "R$ $s" }
    private fun gradient(start: Int, end: Int, radius: Int = 22) = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(start, end)).apply { cornerRadius = dp(radius).toFloat() }
    private fun solid(color: Int, radius: Int = 16) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun text(t: String, size: Float, color: Int = white, bold: Boolean = false) = TextView(this).apply { text=t; textSize=size; setTextColor(color); typeface=if(bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT }

    private fun showHome() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(18), dp(10), dp(18), 0) }
        root.addView(header())
        val scroll=ScrollView(this).apply { isFillViewport=true }
        content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(28)) }
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f)); setContentView(root); renderHome()
    }

    private fun header(): View {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,dp(7),0,dp(8)) }
        val row=LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL }
        val logo=TextView(this).apply { text="CC"; textSize=16f; setTextColor(Color.BLACK); gravity=Gravity.CENTER; typeface=Typeface.DEFAULT_BOLD; background=gradient(cyan,Color.rgb(99,102,241),15) }
        row.addView(logo,LinearLayout.LayoutParams(dp(44),dp(44)))
        val titles=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(11),0,dp(5),0) }
        titles.addView(text("CHRIS CELL",21f,white,true)); titles.addView(text(if(clientMode) "Catálogo para clientes" else "Painel de vendedores",11f,muted)); row.addView(titles,LinearLayout.LayoutParams(0,-2,1f))
        val mode=TextView(this).apply { text=if(clientMode) "VENDA" else "CLIENTE"; textSize=9f; gravity=Gravity.CENTER; setTextColor(if(clientMode) Color.BLACK else white); background=solid(if(clientMode) cyan else panel2,14) }
        mode.setOnClickListener { clientMode=!clientMode; showHome() }
        row.addView(mode,LinearLayout.LayoutParams(dp(62),dp(38)))
        if(!clientMode){ val add=TextView(this).apply { text="+"; textSize=27f; gravity=Gravity.CENTER; setTextColor(white); background=solid(panel2,15) }; add.setOnClickListener{showForm(-1)}; row.addView(add,LinearLayout.LayoutParams(dp(46),dp(46)).apply{marginStart=dp(7)}) }
        box.addView(row); return box
    }

    private fun renderHome(){
        content.removeAllViews(); val all=data()
        if(clientMode){ renderClient(all); return }
        var available=0; var reserved=0; var sold=0
        for(i in 0 until all.length()) when(all.getJSONObject(i).optString("status","Disponível").lowercase()){ "vendido"->sold; "reservado"->reserved; else->available }
        val welcome=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(18));background=gradient(Color.rgb(17,63,82),Color.rgb(28,25,55),24)}
        welcome.addView(text("CATÁLOGO PROFISSIONAL",11f,cyan,true)); welcome.addView(text("Seu estoque. Sua vitrine.",25f,white,true).apply{setPadding(0,dp(4),0,dp(2))}); welcome.addView(text("Cadastre fotos, estoque e preços internos em um só lugar.",13f,Color.rgb(207,216,229)))
        val cta=Button(this).apply{text="＋  CADASTRAR APARELHO";textSize=13f;setTextColor(Color.BLACK);background=solid(cyan,14);isAllCaps=false}; cta.setOnClickListener{showForm(-1)}; welcome.addView(cta,LinearLayout.LayoutParams(-1,dp(48)).apply{topMargin=dp(14)}); content.addView(welcome)
        val stats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(0,dp(14),0,dp(8))}; stats.addView(stat("${all.length()}","TOTAL",cyan),weight()); stats.addView(stat("$available","DISPONÍVEIS",green),weight()); stats.addView(stat("$reserved","RESERVADOS",orange),weight()); stats.addView(stat("$sold","VENDIDOS",red),weight()); content.addView(stats)
        addSearchAndFilters(); content.addView(text("APARELHOS NO ESTOQUE",12f,muted,true).apply{setPadding(2,dp(20),0,dp(8))}); renderList()
    }

    private fun renderClient(all: JSONArray){
        val hero=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(20),dp(18),dp(20));background=gradient(Color.rgb(16,48,65),Color.rgb(30,25,54),24)}
        hero.addView(text("CHRIS CELL",12f,cyan,true)); hero.addView(text("Escolha seu próximo celular",25f,white,true).apply{setPadding(0,dp(5),0,dp(3))}); hero.addView(text("Aparelhos disponíveis • fotos reais • atendimento pelo WhatsApp",12f,Color.rgb(207,216,229))); content.addView(hero)
        addSearchAndFilters(); content.addView(text("DISPONÍVEIS",12f,muted,true).apply{setPadding(2,dp(20),0,dp(8))})
        val holder=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; var count=0
        for(i in 0 until all.length()){val o=all.getJSONObject(i); if(o.optString("status","Disponível").equals("Vendido",true))continue; val cat=o.optString("categoria"); val model=o.optString("modelo"); if(selectedFilter!="Todos"&&cat!=selectedFilter)continue; if(searchText.isNotBlank()&&!model.contains(searchText,true)&&!cat.contains(searchText,true))continue; holder.addView(clientCard(o)); count++}
        if(count==0) holder.addView(empty("Nenhum aparelho disponível","Tente outro modelo ou filtro.")); content.addView(holder)
    }

    private fun addSearchAndFilters(){
        val search=EditText(this).apply{hint="🔎  Buscar por modelo...";setHintTextColor(muted);setTextColor(white);textSize=14f;singleLine=true;setPadding(dp(15),0,dp(15),0);background=solid(panel,15);setText(searchText)}
        search.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){searchText=s?.toString()? : ""; if(::content.isInitialized){if(clientMode)renderClient(data()) else renderList()}};override fun afterTextChanged(e:android.text.Editable?){}})
        content.addView(search,LinearLayout.LayoutParams(-1,dp(50)).apply{bottomMargin=dp(10)})
        val filters=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}; listOf("Todos","Android","iPhone","Outros").forEach{f->val chip=TextView(this).apply{text=f;textSize=11f;gravity=Gravity.CENTER;setTextColor(if(f==selectedFilter)Color.BLACK else white);background=solid(if(f==selectedFilter)cyan else panel,18)};chip.setOnClickListener{selectedFilter=f;showHome()};filters.addView(chip,LinearLayout.LayoutParams(0,dp(38),1f).apply{marginEnd=dp(5)})}; content.addView(filters)
    }

    private fun stat(n:String,l:String,c:Int)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(2,dp(10),2,dp(10));background=solid(panel,15);addView(text(n,20f,c,true));addView(text(l,8f,muted,true))}
    private fun weight()=LinearLayout.LayoutParams(0,dp(70),1f).apply{marginEnd=dp(5)}

    private fun renderList(){val old=content.findViewWithTag<View>("list");if(old!=null)content.removeView(old);val holder=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;tag="list"};val a=data();var count=0;for(i in 0 until a.length()){val o=a.getJSONObject(i);val cat=o.optString("categoria");val model=o.optString("modelo");if(selectedFilter!="Todos"&&cat!=selectedFilter)continue;if(searchText.isNotBlank()&&!model.contains(searchText,true)&&!cat.contains(searchText,true))continue;holder.addView(card(o,i));count++};if(count==0)holder.addView(empty(if(a.length()==0)"Seu estoque está vazio" else "Nenhum aparelho encontrado",if(a.length()==0)"Cadastre o primeiro celular para começar." else "Tente outro modelo ou filtro."));content.addView(holder)}

    private fun empty(title:String,sub:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(20),dp(35),dp(20),dp(35));background=solid(panel,20);addView(text("📱",34f).apply{gravity=Gravity.CENTER});addView(text(title,17f,white,true).apply{gravity=Gravity.CENTER;setPadding(0,dp(8),0,dp(4))});addView(text(sub,12f,muted).apply{gravity=Gravity.CENTER})}

    private fun imageView(uri:String?, width:Int, height:Int): ImageView { val iv=ImageView(this).apply{scaleType=ImageView.ScaleType.CENTER_CROP;background=solid(panel2,18)}; if(!uri.isNullOrBlank())try{iv.setImageURI(Uri.parse(uri))}catch(_:Exception){}; return iv }

    private fun firstPhoto(o:JSONObject):String?=o.optJSONArray("fotos")?.optString(0)?.takeIf{it.isNotBlank()}

    private fun card(o:JSONObject,index:Int):View{
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(12),dp(12),dp(12));background=solid(panel,20)}
        val row=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}; val photo=firstPhoto(o); if(photo!=null)row.addView(imageView(photo,dp(92),dp(92)),LinearLayout.LayoutParams(dp(92),dp(92))) else row.addView(TextView(this).apply{text="📱";textSize=31f;gravity=Gravity.CENTER;background=solid(panel2,18)},LinearLayout.LayoutParams(dp(92),dp(92)))
        val info=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,dp(4),0)}; info.addView(text(o.optString("modelo"),18f,white,true)); info.addView(text(o.optString("categoria")+"  •  "+o.optString("especificacoes"),11f,muted)); val pub=o.optString("precoPublico",o.optString("preco")); info.addView(text("Venda: "+money(pub),16f,cyan,true)); if(o.optString("precoRevenda").isNotBlank())info.addView(text("Revenda: "+money(o.optString("precoRevenda")),11f,orange)); row.addView(info,LinearLayout.LayoutParams(0,-2,1f)); val status=o.optString("status","Disponível");row.addView(badge(status));box.addView(row)
        val buttons=LinearLayout(this).apply{setPadding(0,dp(10),0,0)};val edit=Button(this).apply{text="EDITAR";textSize=11f;isAllCaps=false;setTextColor(white);background=solid(panel2,12)};edit.setOnClickListener{showForm(index)};val del=Button(this).apply{text="EXCLUIR";textSize=11f;isAllCaps=false;setTextColor(red);background=solid(panel2,12)};del.setOnClickListener{val a=data();a.remove(index);save(a);renderHome()};buttons.addView(edit,LinearLayout.LayoutParams(0,dp(42),1f).apply{marginEnd=dp(5)});buttons.addView(del,LinearLayout.LayoutParams(0,dp(42),1f).apply{marginStart=dp(5)});box.addView(buttons);return box.apply{layoutParams=LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT).apply{bottomMargin=dp(10)}}
    }

    private fun clientCard(o:JSONObject):View{
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;background=solid(panel,22)};val photo=firstPhoto(o);if(photo!=null)box.addView(imageView(photo,dp(330),dp(210)),LinearLayout.LayoutParams(-1,dp(210))) else box.addView(TextView(this).apply{text="📱\nSem foto";textSize=26f;gravity=Gravity.CENTER;setTextColor(muted);background=solid(panel2,22)},LinearLayout.LayoutParams(-1,dp(210)))
        val info=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(15),dp(13),dp(15),dp(15))};info.addView(text(o.optString("modelo"),20f,white,true));info.addView(text(o.optString("categoria")+"  •  "+o.optString("especificacoes"),12f,muted));val pub=o.optString("precoPublico",o.optString("preco"));if(pub.isNotBlank())info.addView(text(money(pub),20f,cyan,true).apply{setPadding(0,dp(5),0,dp(2))});val b=Button(this).apply{text="TENHO INTERESSE  ›";textSize=12f;isAllCaps=false;setTextColor(Color.BLACK);background=solid(cyan,14)};b.setOnClickListener{Toast.makeText(this,"Interesse registrado! Agora você pode chamar o vendedor pelo WhatsApp.",Toast.LENGTH_LONG).show()};info.addView(b,LinearLayout.LayoutParams(-1,dp(46)).apply{topMargin=dp(10)});box.addView(info);return box.apply{layoutParams=LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(12)}}
    }

    private fun badge(status:String)=TextView(this).apply{text=status;textSize=9f;gravity=Gravity.CENTER;setTextColor(Color.BLACK);background=solid(when(status.lowercase()){"vendido"->red;"reservado"->orange;else->green},12);layoutParams=LinearLayout.LayoutParams(dp(78),dp(28))}

    private fun field(hint:String,value:String,multi:Boolean=false)=EditText(this).apply{this.hint=hint;setHintTextColor(muted);setTextColor(white);textSize=14f;setText(value);setPadding(dp(14),dp(6),dp(14),dp(6));background=solid(panel,14);if(multi)minLines=3}

    private fun showForm(index:Int){
        editingIndex = index
        val a=data();val old=if(index>=0)a.getJSONObject(index)else JSONObject();pendingPhotoUris=mutableListOf<String>().apply{old.optJSONArray("fotos")?.let{for(i in 0 until it.length())add(it.optString(i))}}
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bg);setPadding(dp(18),dp(14),dp(18),dp(18))};val top=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL};val back=TextView(this).apply{text="‹";textSize=34f;setTextColor(white);gravity=Gravity.CENTER};back.setOnClickListener{showHome()};top.addView(back,LinearLayout.LayoutParams(dp(45),dp(48)));top.addView(text(if(index>=0)"Editar aparelho" else "Novo aparelho",22f,white,true),LinearLayout.LayoutParams(0,-2,1f));root.addView(top)
        val scroll=ScrollView(this);val form=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val gallery=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(12),dp(12),dp(12));background=solid(panel,20)};gallery.addView(text("FOTOS DO APARELHO",11f,cyan,true));photoRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL};gallery.addView(photoRow,LinearLayout.LayoutParams(-1,dp(112)).apply{topMargin=dp(8)});val addPhoto=Button(this).apply{text="＋\nADICIONAR FOTOS";textSize=10f;isAllCaps=false;setTextColor(white);background=solid(panel2,15)};addPhoto.setOnClickListener{val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);addCategory(Intent.CATEGORY_OPENABLE)};startActivityForResult(intent,101)};photoRow.addView(addPhoto,LinearLayout.LayoutParams(dp(110),dp(104)));renderPhotoThumbs(photoRow);form.addView(gallery)
        val cat=field("Categoria: Android / iPhone / Outros",old.optString("categoria"));val model=field("Modelo (ex.: iPhone 13 128 GB)",old.optString("modelo"));val spec=field("Especificações (RAM, armazenamento, bateria...)",old.optString("especificacoes"));val rev=field("Preço para revendedor (interno)",old.optString("precoRevenda",old.optString("preco")));val pub=field("Preço para cliente",old.optString("precoPublico",old.optString("preco")));val status=field("Status: Disponível / Reservado / Vendido",old.optString("status","Disponível"));val obs=field("Observações",old.optString("observacoes"),true)
        listOf(cat to "Categoria",model to "Modelo",spec to "Especificações",rev to "Preço para revendedor",pub to "Preço para cliente",status to "Status",obs to "Observações").forEach{(e,l)->form.addView(text(l,11f,muted,true).apply{setPadding(dp(3),dp(10),0,dp(5))});form.addView(e,LinearLayout.LayoutParams(-1,if(e==obs)dp(100)else dp(52)).apply{bottomMargin=dp(2)})}
        val saveBtn=Button(this).apply{text="SALVAR APARELHO";textSize=13f;setTextColor(Color.BLACK);background=solid(cyan,15);isAllCaps=false};saveBtn.setOnClickListener{if(model.text.toString().trim().isEmpty()){Toast.makeText(this,"Digite o modelo",Toast.LENGTH_SHORT).show();return@setOnClickListener};val o=JSONObject().apply{put("categoria",cat.text.toString().ifBlank{"Android"});put("modelo",model.text.toString());put("especificacoes",spec.text.toString());put("precoRevenda",rev.text.toString());put("precoPublico",pub.text.toString());put("preco",pub.text.toString());put("status",status.text.toString().ifBlank{"Disponível"});put("observacoes",obs.text.toString());put("fotos",JSONArray(pendingPhotoUris))};if(index>=0)a.put(index,o)else a.put(o);save(a);showHome()};form.addView(saveBtn,LinearLayout.LayoutParams(-1,dp(52)).apply{topMargin=dp(18)});scroll.addView(form);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));setContentView(root)
    }

    private fun renderPhotoThumbs(container:LinearLayout){for(uri in pendingPhotoUris.take(3)){container.addView(imageView(uri,dp(100),dp(100)),LinearLayout.LayoutParams(dp(100),dp(100)).apply{marginEnd=dp(6)})}}

    override fun onActivityResult(requestCode:Int,resultCode:Int,dataIntent:Intent?){super.onActivityResult(requestCode,resultCode,dataIntent);if(requestCode==101&&resultCode==RESULT_OK){if(dataIntent?.clipData!=null){val c=dataIntent.clipData!!;for(i in 0 until c.itemCount)pendingPhotoUris.add(c.getItemAt(i).uri.toString())}else dataIntent?.data?.let{pendingPhotoUris.add(it.toString())};if(::photoRow.isInitialized){photoRow.removeAllViews();val addPhoto=Button(this).apply{text="＋\nADICIONAR FOTOS";textSize=10f;isAllCaps=false;setTextColor(white);background=solid(panel2,15)};addPhoto.setOnClickListener{val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);addCategory(Intent.CATEGORY_OPENABLE)};startActivityForResult(intent,101)};photoRow.addView(addPhoto,LinearLayout.LayoutParams(dp(110),dp(104)));renderPhotoThumbs(photoRow)}}}
}
