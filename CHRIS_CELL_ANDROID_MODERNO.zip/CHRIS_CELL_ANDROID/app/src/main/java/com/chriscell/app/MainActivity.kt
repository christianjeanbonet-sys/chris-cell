package com.chriscell.app

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("estoque", Context.MODE_PRIVATE) }
    private lateinit var content: LinearLayout
    private var selectedFilter = "Todos"
    private var searchText = ""
    private val bg = Color.rgb(8, 11, 16)
    private val panel = Color.rgb(18, 23, 31)
    private val panel2 = Color.rgb(24, 30, 40)
    private val white = Color.WHITE
    private val muted = Color.rgb(155, 166, 181)
    private val cyan = Color.rgb(42, 211, 255)
    private val green = Color.rgb(52, 211, 153)
    private val orange = Color.rgb(251, 191, 36)
    private val red = Color.rgb(248, 113, 113)

    override fun onCreate(b: Bundle?) { super.onCreate(b); showHome() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun data() = JSONArray(prefs.getString("items", "[]"))
    private fun save(a: JSONArray) = prefs.edit().putString("items", a.toString()).apply()
    private fun money(s: String): String = try {
        NumberFormat.getCurrencyInstance(Locale("pt", "BR")).format(s.replace(",", ".").toDouble())
    } catch (_: Exception) { if (s.isBlank()) "R$ 0,00" else "R$ $s" }

    private fun gradient(start: Int, end: Int, radius: Float = 24f): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(start, end)).apply { cornerRadius = dp(radius.toInt()).toFloat() }
    private fun solid(color: Int, radius: Int = 18): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun text(t: String, size: Float, color: Int = white, bold: Boolean = false): TextView = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private fun showHome() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(18), dp(14), dp(18), 0) }
        root.addView(header())
        val scroll = ScrollView(this).apply { isFillViewport = true }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(24)) }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        renderHome()
    }

    private fun header(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(10)) }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val logo = TextView(this).apply {
            text = "CC"; textSize = 17f; setTextColor(Color.BLACK); gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
            background = gradient(cyan, Color.rgb(99, 102, 241), 15f)
        }
        row.addView(logo, LinearLayout.LayoutParams(dp(44), dp(44)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        titles.addView(text("CHRIS CELL", 22f, white, true))
        titles.addView(text("Seu estoque, do seu jeito", 12f, muted))
        row.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        val add = TextView(this).apply { text = "+"; textSize = 28f; gravity = Gravity.CENTER; setTextColor(white); background = solid(panel2, 15) }
        add.setOnClickListener { showForm(-1) }
        row.addView(add, LinearLayout.LayoutParams(dp(48), dp(48)))
        box.addView(row)
        return box
    }

    private fun renderHome() {
        content.removeAllViews()
        val all = data()
        val total = all.length()
        var available = 0; var reserved = 0; var sold = 0
        for (i in 0 until total) when (all.getJSONObject(i).optString("status", "Disponível").lowercase()) {
            "vendido" -> sold++; "reservado" -> reserved++; else -> available++
        }

        val welcome = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18)); background = gradient(Color.rgb(20, 55, 73), Color.rgb(23, 25, 48), 24f) }
        welcome.addView(text("ESTOQUE DE CELULARES", 11f, cyan, true))
        welcome.addView(text("Venda mais. Organize melhor.", 25f, white, true).apply { setPadding(0, dp(4), 0, dp(2)) })
        welcome.addView(text("Cadastre seus aparelhos e acompanhe tudo em um só lugar.", 13f, Color.rgb(204, 213, 225)))
        val cta = Button(this).apply { text = "＋  CADASTRAR APARELHO"; textSize = 13f; setTextColor(Color.BLACK); background = solid(cyan, 14); isAllCaps = false }
        cta.setOnClickListener { showForm(-1) }
        val cp = LinearLayout.LayoutParams(-1, dp(48)); cp.topMargin = dp(14); welcome.addView(cta, cp)
        content.addView(welcome)

        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(14), 0, dp(8)) }
        stats.addView(stat("$total", "TOTAL", cyan), weightParams())
        stats.addView(stat("$available", "DISPONÍVEIS", green), weightParams())
        stats.addView(stat("$reserved", "RESERVADOS", orange), weightParams())
        stats.addView(stat("$sold", "VENDIDOS", red), weightParams())
        content.addView(stats)

        val search = EditText(this).apply {
            hint = "🔎  Buscar modelo..."; setHintTextColor(muted); setTextColor(white); textSize = 14f; singleLine = true
            setPadding(dp(15), 0, dp(15), 0); background = solid(panel, 15); setText(searchText)
        }
        search.setOnEditorActionListener { _, _, _ -> searchText = search.text.toString(); renderList(); true }
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) { searchText = s?.toString() ?: ""; renderList() }
            override fun afterTextChanged(e: android.text.Editable?) {}
        })
        content.addView(search, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(10) })

        val filters = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Todos", "Android", "iPhone", "Quebra-Galho").forEach { f ->
            val chip = TextView(this).apply { text = f; textSize = 12f; gravity = Gravity.CENTER; setTextColor(if (f == selectedFilter) Color.BLACK else white); background = solid(if (f == selectedFilter) cyan else panel, 18) }
            chip.setOnClickListener { selectedFilter = f; renderHome() }
            filters.addView(chip, LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginEnd = dp(5) })
        }
        content.addView(filters)
        content.addView(text("APARELHOS NO ESTOQUE", 12f, muted, true).apply { setPadding(2, dp(20), 0, dp(8)) })
        renderList()
    }

    private fun stat(number: String, label: String, color: Int): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(2, dp(10), 2, dp(10)); background = solid(panel, 15)
        addView(text(number, 20f, color, true)); addView(text(label, 8f, muted, true))
    }
    private fun weightParams() = LinearLayout.LayoutParams(0, dp(70), 1f).apply { marginEnd = dp(5) }

    private fun renderList() {
        val old = content.findViewWithTag<View>("list")
        if (old != null) content.removeView(old)
        val holder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; tag = "list" }
        val a = data()
        var count = 0
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val cat = o.optString("categoria")
            val model = o.optString("modelo")
            val status = o.optString("status", "Disponível")
            if (selectedFilter != "Todos" && cat != selectedFilter) continue
            if (searchText.isNotBlank() && !model.contains(searchText, true) && !cat.contains(searchText, true)) continue
            holder.addView(card(o, i)); count++
        }
        if (count == 0) {
            val empty = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(20), dp(35), dp(20), dp(35)); background = solid(panel, 20) }
            empty.addView(text("📱", 34f, white, false).apply { gravity = Gravity.CENTER })
            empty.addView(text(if (a.length() == 0) "Seu estoque está vazio" else "Nenhum aparelho encontrado", 17f, white, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(4)) })
            empty.addView(text(if (a.length() == 0) "Cadastre o primeiro celular para começar." else "Tente outro modelo ou filtro.", 12f, muted).apply { gravity = Gravity.CENTER })
            holder.addView(empty)
        }
        content.addView(holder)
    }

    private fun card(o: JSONObject, index: Int): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(15), dp(14), dp(15), dp(14)); background = solid(panel, 20) }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val icon = TextView(this).apply { text = "📱"; textSize = 25f; gravity = Gravity.CENTER; background = solid(panel2, 16) }
        top.addView(icon, LinearLayout.LayoutParams(dp(55), dp(55)))
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(6), 0) }
        info.addView(text(o.optString("modelo"), 17f, white, true))
        info.addView(text(o.optString("categoria") + "  •  " + o.optString("especificacoes"), 11f, muted))
        info.addView(text(money(o.optString("preco")), 17f, cyan, true))
        top.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        val status = o.optString("status", "Disponível")
        val badge = TextView(this).apply { text = status; textSize = 10f; gravity = Gravity.CENTER; setTextColor(Color.BLACK); background = solid(when (status.lowercase()) { "vendido" -> red; "reservado" -> orange; else -> green }, 12) }
        top.addView(badge, LinearLayout.LayoutParams(dp(78), dp(28)))
        box.addView(top)
        val buttons = LinearLayout(this).apply { setPadding(0, dp(10), 0, 0) }
        val edit = Button(this).apply { text = "EDITAR"; textSize = 11f; isAllCaps = false; setTextColor(white); background = solid(panel2, 12) }
        edit.setOnClickListener { showForm(index) }
        val del = Button(this).apply { text = "EXCLUIR"; textSize = 11f; isAllCaps = false; setTextColor(red); background = solid(panel2, 12) }
        del.setOnClickListener { val a = data(); a.remove(index); save(a); renderHome() }
        buttons.addView(edit, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) })
        buttons.addView(del, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(5) })
        box.addView(buttons)
        return box.apply { layoutParams = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) } }
    }

    private fun field(hint: String, value: String, multi: Boolean = false): EditText = EditText(this).apply {
        this.hint = hint; setHintTextColor(muted); setTextColor(white); textSize = 14f; setText(value); setPadding(dp(14), dp(6), dp(14), dp(6)); background = solid(panel, 14)
        if (multi) minLines = 3
    }

    private fun showForm(index: Int) {
        val a = data(); val old = if (index >= 0) a.getJSONObject(index) else JSONObject()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(18), dp(18), dp(18), dp(18)) }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val back = TextView(this).apply { text = "‹"; textSize = 34f; setTextColor(white); gravity = Gravity.CENTER }
        back.setOnClickListener { showHome() }; top.addView(back, LinearLayout.LayoutParams(dp(45), dp(48)))
        top.addView(text(if (index >= 0) "Editar aparelho" else "Novo aparelho", 22f, white, true), LinearLayout.LayoutParams(0, -2, 1f)); root.addView(top)
        root.addView(text("Preencha as informações do aparelho", 12f, muted).apply { setPadding(dp(45), 0, 0, dp(15)) })
        val scroll = ScrollView(this); val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val cat = field("Categoria: Android / iPhone / Quebra-Galho", old.optString("categoria")); val model = field("Modelo (ex.: iPhone 13 128 GB)", old.optString("modelo")); val spec = field("Especificações (RAM, armazenamento...)", old.optString("especificacoes")); val price = field("Preço", old.optString("preco")); val status = field("Status: Disponível / Reservado / Vendido", old.optString("status", "Disponível")); val obs = field("Observações", old.optString("observacoes"), true)
        listOf(cat to "Categoria", model to "Modelo", spec to "Especificações", price to "Preço", status to "Status", obs to "Observações").forEach { (e, label) -> form.addView(text(label, 11f, muted, true).apply { setPadding(dp(3), dp(8), 0, dp(5)) }); form.addView(e, LinearLayout.LayoutParams(-1, if (e == obs) dp(100) else dp(52)).apply { bottomMargin = dp(4) }) }
        val saveBtn = Button(this).apply { text = "SALVAR APARELHO"; textSize = 13f; setTextColor(Color.BLACK); background = solid(cyan, 15); isAllCaps = false }
        saveBtn.setOnClickListener {
            if (model.text.toString().trim().isEmpty()) { Toast.makeText(this, "Digite o modelo", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val o = JSONObject().apply { put("categoria", cat.text.toString().ifBlank { "Android" }); put("modelo", model.text.toString()); put("especificacoes", spec.text.toString()); put("preco", price.text.toString()); put("status", status.text.toString().ifBlank { "Disponível" }); put("observacoes", obs.text.toString()) }
            if (index >= 0) a.put(index, o) else a.put(o); save(a); showHome()
        }
        form.addView(saveBtn, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(18) }); scroll.addView(form); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f)); setContentView(root)
    }
}
