package com.chriscell.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("estoque", Context.MODE_PRIVATE) }
    private lateinit var content: LinearLayout
    private var selectedFilter = "Todos"
    private var searchText = ""
    private var sellerMode = false
    private var editingIndex = -1
    private var pickedPhoto: Uri? = null

    private val bg = Color.rgb(8, 11, 16)
    private val panel = Color.rgb(18, 23, 31)
    private val panel2 = Color.rgb(27, 34, 45)
    private val white = Color.WHITE
    private val muted = Color.rgb(155, 166, 181)
    private val cyan = Color.rgb(42, 211, 255)
    private val green = Color.rgb(52, 211, 153)
    private val orange = Color.rgb(251, 191, 36)
    private val red = Color.rgb(248, 113, 113)

    override fun onCreate(b: Bundle?) { super.onCreate(b); showCatalog() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun data() = JSONArray(prefs.getString("items", "[]"))
    private fun save(a: JSONArray) = prefs.edit().putString("items", a.toString()).apply()
    private fun money(s: String): String = try { NumberFormat.getCurrencyInstance(Locale("pt", "BR")).format(s.replace(",", ".").toDouble()) } catch (_: Exception) { if (s.isBlank()) "R$ 0,00" else "R$ $s" }
    private fun solid(color: Int, radius: Int = 18) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun gradient(a: Int, b: Int, radius: Int = 22) = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(a, b)).apply { cornerRadius = dp(radius).toFloat() }
    private fun text(t: String, size: Float, color: Int = white, bold: Boolean = false) = TextView(this).apply { text = t; textSize = size; setTextColor(color); typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT }

    private fun baseRoot(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(18), dp(14), dp(18), 0) }

    private fun showCatalog() {
        sellerMode = false
        val root = baseRoot()
        root.addView(header("Catálogo público", false))
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(24)) }
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f)); setContentView(root)
        renderCatalog()
    }

    private fun showSeller() {
        sellerMode = true
        val root = baseRoot()
        root.addView(header("Área dos vendedores", true))
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(24)) }
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f)); setContentView(root)
        renderSeller()
    }

    private fun header(subtitle: String, seller: Boolean): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(10)) }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val logo = TextView(this).apply { text = "CC"; textSize = 16f; setTextColor(Color.BLACK); gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD; background = gradient(cyan, Color.rgb(99,102,241), 15) }
        row.addView(logo, LinearLayout.LayoutParams(dp(44), dp(44)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        titles.addView(text("CHRIS CELL", 21f, white, true)); titles.addView(text(subtitle, 12f, muted)); row.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        if (seller) {
            val back = Button(this).apply { text = "CATÁLOGO"; textSize = 10f; isAllCaps = false; setTextColor(white); background = solid(panel2, 12) }; back.setOnClickListener { showCatalog() }; row.addView(back, LinearLayout.LayoutParams(dp(88), dp(44)))
        } else {
            val admin = Button(this).apply { text = "VENDEDOR"; textSize = 10f; isAllCaps = false; setTextColor(white); background = solid(panel2, 12) }; admin.setOnClickListener { askPin() }; row.addView(admin, LinearLayout.LayoutParams(dp(88), dp(44)))
        }
        box.addView(row); return box
    }

    private fun askPin() {
        val input = EditText(this).apply { hint = "PIN do vendedor"; inputType = 2; setTextColor(white); setHintTextColor(muted) }
        AlertDialog.Builder(this).setTitle("Área dos vendedores").setMessage("Digite o PIN para entrar.").setView(input).setNegativeButton("Cancelar", null).setPositiveButton("Entrar") { _, _ -> if (input.text.toString() == "1234") showSeller() else Toast.makeText(this, "PIN incorreto", Toast.LENGTH_SHORT).show() }.show()
    }

    private fun renderCatalog() {
        content.removeAllViews()
        val hero = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(20), dp(18), dp(20)); background = gradient(Color.rgb(20,55,73), Color.rgb(23,25,48), 24) }
        hero.addView(text("CHRIS CELL", 11f, cyan, true)); hero.addView(text("Celulares disponíveis", 25f, white, true).apply { setPadding(0, dp(5), 0, dp(2)) }); hero.addView(text("Escolha seu aparelho e fale com o vendedor.", 13f, Color.rgb(204,213,225)))
        content.addView(hero)
        addSearchAndFilters()
        content.addView(text("APARELHOS DISPONÍVEIS", 12f, muted, true).apply { setPadding(2, dp(18), 0, dp(8)) })
        renderList(false)
    }

    private fun renderSeller() {
        content.removeAllViews()
        val all = data(); var available=0; var reserved=0; var sold=0
        for(i in 0 until all.length()) when(all.getJSONObject(i).optString("status","Disponível").lowercase()) { "vendido"->sold; "reservado"->reserved; else->available }
        val banner = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(18),dp(18),dp(18)); background=gradient(Color.rgb(28,49,61),Color.rgb(29,28,51),22) }
        banner.addView(text("PAINEL INTERNO",11f,cyan,true)); banner.addView(text("Gerencie seu estoque",24f,white,true).apply{setPadding(0,dp(4),0,dp(2))}); banner.addView(text("Você pode cadastrar, editar, colocar fotos e controlar o preço de custo.",13f,Color.rgb(204,213,225)))
        val add=Button(this).apply{text="＋  NOVO APARELHO"; textSize=13f; isAllCaps=false; setTextColor(Color.BLACK); background=solid(cyan,14)}; add.setOnClickListener{showForm(-1)}; banner.addView(add,LinearLayout.LayoutParams(-1,dp(48)).apply{topMargin=dp(14)})
        content.addView(banner)
        val stats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(0,dp(14),0,dp(8))}; stats.addView(stat("${all.length()}","TOTAL",cyan),weightParams());stats.addView(stat("$available","DISPONÍVEIS",green),weightParams());stats.addView(stat("$reserved","RESERVADOS",orange),weightParams());stats.addView(stat("$sold","VENDIDOS",red),weightParams());content.addView(stats)
        addSearchAndFilters(); content.addView(text("ESTOQUE INTERNO",12f,muted,true).apply{setPadding(2,dp(18),0,dp(8))}); renderList(true)
    }

    private fun addSearchAndFilters() {
        val search=EditText(this).apply{hint="🔎  Buscar modelo...";setHintTextColor(muted);setTextColor(white);textSize=14f;singleLine=true;setPadding(dp(15),0,dp(15),0);background=solid(panel,15);setText(searchText)}
        search.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){searchText=s?.toString() ?: ""; if(sellerMode) renderSeller() else renderCatalog()};override fun afterTextChanged(e:android.text.Editable?) {}})
        content.addView(search,LinearLayout.LayoutParams(-1,dp(50)).apply{bottomMargin=dp(10)})
        val filters=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}; listOf("Todos","Android","iPhone","Quebra-Galho").forEach{f->val chip=TextView(this).apply{text=f;textSize=12f;gravity=Gravity.CENTER;setTextColor(if(f==selectedFilter)Color.BLACK else white);background=solid(if(f==selectedFilter)cyan else panel,18)};chip.setOnClickListener{selectedFilter=f;if(sellerMode)renderSeller()else renderCatalog()};filters.addView(chip,LinearLayout.LayoutParams(0,dp(38),1f).apply{marginEnd=dp(5)})};content.addView(filters)
    }

    private fun stat(n:String,l:String,c:Int):View=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(2,dp(10),2,dp(10));background=solid(panel,15);addView(text(n,20f,c,true));addView(text(l,8f,muted,true))}
    private fun weightParams()=LinearLayout.LayoutParams(0,dp(70),1f).apply{marginEnd=dp(5)}

    private fun renderList(internal:Boolean) {
        val old=content.findViewWithTag<View>("list"); if(old!=null)content.removeView(old)
        val holder=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;tag="list"}; val a=data(); var count=0
        for(i in 0 until a.length()){val o=a.getJSONObject(i);val cat=o.optString("categoria");val model=o.optString("modelo");val status=o.optString("status","Disponível");if(selectedFilter!="Todos"&&cat!=selectedFilter)continue;if(searchText.isNotBlank()&&!model.contains(searchText,true)&&!cat.contains(searchText,true))continue;if(!internal&&status.lowercase()!="disponível")continue;holder.addView(card(o,i,internal));count++}
        if(count==0){holder.addView(LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(20),dp(35),dp(20),dp(35));background=solid(panel,20);addView(text("📱",34f));addView(text("Nenhum aparelho encontrado",17f,white,true));addView(text(if(internal)"Cadastre seu primeiro celular." else "Confira novamente mais tarde.",12f,muted))})};content.addView(holder)
    }

    private fun card(o:JSONObject,index:Int,internal:Boolean):View{
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(15),dp(14),dp(15),dp(14));background=solid(panel,20)}
        val top=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}; val photo=o.optString("foto"); if(photo.isNotBlank()){val iv=ImageView(this);iv.scaleType=ImageView.ScaleType.CENTER_CROP;try{iv.setImageURI(Uri.parse(photo))}catch(_:Exception){};iv.background=solid(panel2,16);top.addView(iv,LinearLayout.LayoutParams(dp(72),dp(72)))}else{top.addView(TextView(this).apply{text="📱";textSize=28f;gravity=Gravity.CENTER;background=solid(panel2,16)},LinearLayout.LayoutParams(dp(72),dp(72)))}
        val info=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,dp(5),0)};info.addView(text(o.optString("modelo"),17f,white,true));info.addView(text(o.optString("categoria")+"  •  "+o.optString("especificacoes"),11f,muted));info.addView(text(money(o.optString("preco")),17f,cyan,true));if(internal&&o.optString("custo").isNotBlank())info.addView(text("Custo: "+money(o.optString("custo")),11f,orange));if(o.optString("bateria").isNotBlank())info.addView(text("Bateria: "+o.optString("bateria"),11f,muted));top.addView(info,LinearLayout.LayoutParams(0,-2,1f));val status=o.optString("status","Disponível");val badge=TextView(this).apply{text=status;textSize=10f;gravity=Gravity.CENTER;setTextColor(Color.BLACK);background=solid(when(status.lowercase()){"vendido"->red;"reservado"->orange;else->green},12)};top.addView(badge,LinearLayout.LayoutParams(dp(78),dp(28)));box.addView(top)
        if(o.optString("cor").isNotBlank())box.addView(text("Cor: "+o.optString("cor"),11f,muted).apply{setPadding(dp(84),dp(5),0,0)})
        if(o.optString("observacoes").isNotBlank())box.addView(text(o.optString("observacoes"),11f,muted).apply{setPadding(dp(84),dp(3),0,0)})
        if(internal){val buttons=LinearLayout(this).apply{setPadding(0,dp(10),0,0)};val edit=Button(this).apply{text="EDITAR";textSize=11f;isAllCaps=false;setTextColor(white);background=solid(panel2,12)};edit.setOnClickListener{showForm(index)};val del=Button(this).apply{text="EXCLUIR";textSize=11f;isAllCaps=false;setTextColor(red);background=solid(panel2,12)};del.setOnClickListener{val x=data();x.remove(index);save(x);renderSeller()};buttons.addView(edit,LinearLayout.LayoutParams(0,dp(42),1f).apply{marginEnd=dp(5)});buttons.addView(del,LinearLayout.LayoutParams(0,dp(42),1f).apply{marginStart=dp(5)});box.addView(buttons)}else{val interest=Button(this).apply{text="TENHO INTERESSE • WHATSAPP";textSize=12f;isAllCaps=false;setTextColor(Color.BLACK);background=solid(green,13)};interest.setOnClickListener{val msg=Uri.encode("Olá! Tenho interesse no ${o.optString("modelo")}. Ainda está disponível?");startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/?text=$msg")))};box.addView(interest,LinearLayout.LayoutParams(-1,dp(44)).apply{topMargin=dp(10)})}
        return box.apply{layoutParams=LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT).apply{bottomMargin=dp(10)}}
    }

    private fun field(h:String,v:String,m:Boolean=false)=EditText(this).apply{hint=h;setHintTextColor(muted);setTextColor(white);textSize=14f;setText(v);setPadding(dp(14),dp(6),dp(14),dp(6));background=solid(panel,14);if(m)minLines=3}

    private fun showForm(index:Int){editingIndex=index;pickedPhoto=null;val a=data();val old=if(index>=0)a.getJSONObject(index)else JSONObject();val root=baseRoot();val top=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL};val back=TextView(this).apply{text="‹";textSize=34f;setTextColor(white);gravity=Gravity.CENTER};back.setOnClickListener{showSeller()};top.addView(back,LinearLayout.LayoutParams(dp(45),dp(48)));top.addView(text(if(index>=0)"Editar aparelho" else "Novo aparelho",22f,white,true),LinearLayout.LayoutParams(0,-2,1f));root.addView(top)
        val scroll=ScrollView(this);val form=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val photoPreview=ImageView(this).apply{scaleType=ImageView.ScaleType.CENTER_CROP;background=solid(panel,18);setImageURI(if(old.optString("foto").isBlank())null else Uri.parse(old.optString("foto")))};form.addView(photoPreview,LinearLayout.LayoutParams(-1,dp(190)).apply{bottomMargin=dp(8)})
        val photoBtn=Button(this).apply{text="📷  ESCOLHER FOTOS DO CELULAR";isAllCaps=false;textSize=12f;setTextColor(white);background=solid(panel2,14)};photoBtn.setOnClickListener{val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";putExtra(Intent.EXTRA_ALLOW_MULTIPLE,false);addCategory(Intent.CATEGORY_OPENABLE)};startActivityForResult(i,501)};form.addView(photoBtn,LinearLayout.LayoutParams(-1,dp(48)).apply{bottomMargin=dp(10)})
        val cat=field("Categoria: Android / iPhone / Quebra-Galho",old.optString("categoria"));val model=field("Modelo (ex.: iPhone 13 128 GB)",old.optString("modelo"));val spec=field("Especificações / armazenamento",old.optString("especificacoes"));val color=field("Cor",old.optString("cor"));val battery=field("Saúde da bateria (ex.: 100%)",old.optString("bateria"));val price=field("Preço de venda",old.optString("preco"));val cost=field("Preço de custo (somente vendedores)",old.optString("custo"));val vendor=field("Vendedor: 1 / 2 / 3",old.optString("vendedor"));val status=field("Status: Disponível / Reservado / Vendido",old.optString("status","Disponível"));val obs=field("Observações",old.optString("observacoes"),true)
        listOf(cat to "Categoria",model to "Modelo",spec to "Especificações",color to "Cor",battery to "Bateria",price to "Preço de venda",cost to "Preço de custo",vendor to "Vendedor",status to "Status",obs to "Observações").forEach{(e,l)->form.addView(text(l,11f,muted,true).apply{setPadding(dp(3),dp(8),0,dp(5))});form.addView(e,LinearLayout.LayoutParams(-1,if(e==obs)dp(100)else dp(52)).apply{bottomMargin=dp(3)})}
        val saveBtn=Button(this).apply{text="SALVAR APARELHO";textSize=13f;setTextColor(Color.BLACK);background=solid(cyan,15);isAllCaps=false};saveBtn.setOnClickListener{if(model.text.toString().trim().isEmpty()){Toast.makeText(this,"Digite o modelo",Toast.LENGTH_SHORT).show();return@setOnClickListener};val o=JSONObject().apply{put("categoria",cat.text.toString().ifBlank{"Android"});put("modelo",model.text.toString());put("especificacoes",spec.text.toString());put("cor",color.text.toString());put("bateria",battery.text.toString());put("preco",price.text.toString());put("custo",cost.text.toString());put("vendedor",vendor.text.toString().ifBlank{"1"});put("status",status.text.toString().ifBlank{"Disponível"});put("observacoes",obs.text.toString());put("foto",pickedPhoto?.toString()?:old.optString("foto"))};if(index>=0)a.put(index,o)else a.put(o);save(a);showSeller()};form.addView(saveBtn,LinearLayout.LayoutParams(-1,dp(52)).apply{topMargin=dp(18)});scroll.addView(form);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));setContentView(root)
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,dataIntent:Intent?){super.onActivityResult(requestCode,resultCode,dataIntent);if(requestCode==501&&resultCode==RESULT_OK){val uri=dataIntent?.data;if(uri!=null){pickedPhoto=uri;try{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){};showForm(editingIndex)}}}
}
