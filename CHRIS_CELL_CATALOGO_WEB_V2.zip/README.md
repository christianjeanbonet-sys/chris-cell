# Chris Cell — Catálogo Web

Versão inicial do catálogo:
- catálogo público responsivo;
- área do vendedor;
- cadastro, edição e exclusão;
- foto pela galeria do celular;
- busca e filtros;
- botão Tenho Interesse;
- armazenamento local no navegador.

IMPORTANTE:
Esta versão é um protótipo funcional no navegador. Para 3 vendedores usarem de aparelhos diferentes e todos enxergarem o mesmo estoque, é necessário conectar um banco online (ex.: Supabase/Firebase). O próximo passo é fazer essa conexão.
